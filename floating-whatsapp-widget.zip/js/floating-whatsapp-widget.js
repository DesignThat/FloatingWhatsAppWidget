// JavaScript code for any custom functionality (if needed)
// You can add your custom JavaScript code here
// Example: If you want to perform some action on widget click
// you can use the code below:

// jQuery(document).ready(function($) {
//     $('#floating-whatsapp-widget').on('click', function() {
//         // Perform your action here
//     });
// });
